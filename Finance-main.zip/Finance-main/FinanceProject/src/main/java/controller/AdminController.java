package controller;

import java.util.List;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import Service.AdminService;
import Service.AdminServiceImplementation;
import Service.CustomerAlreadyPresentException;
import Service.CustomerNotEligibleException;
import Service.CustomerNotFoundException;
import Service.ProductAlreadyExistsException;
import entities.Customer;
import entities.Product;

//@Path("/currencies") // http://localhost:8082/FinanceProject/rest/admin
@Path("/admin")
public class AdminController {
	AdminService adminService = new AdminServiceImplementation();
	
	@GET				//action mappings
	@Path("/greet") //http://localhost:8080/MyRestAPI2/rest/currency/greet
	public String welcome() {
		return "<h1> Welcome to Web Based Controller </h1>";
	}
	
		@GET  @Produces(MediaType.APPLICATION_JSON)
		public List<Customer> Viewalluser() {
			// TODO Auto-generated method stub
			System.out.println("controller : viewalluser()");
			return adminService.Viewalluser();
		}
		
		@DELETE
		@Path("/delete/{cid}")
		public Response RevokeUser(@PathParam("cid") int id) {
			
			adminService.RevokeUser(id);
			
			return Response
					.status(Response.Status.OK)
					.entity("User Deleted")
					.build();

		}
		
		@PUT
		@Path("/updateUser") 
		public Response ModifyUser(Customer customer1) throws CustomerNotFoundException {
			try {
				adminService.ModifyUser(customer1);
				return Response
					      .status(Response.Status.OK)
					      .entity("Currency Modified")
					      .build();
					} catch (CustomerNotFoundException e) {
						return Response
					      .status(Response.Status.NOT_FOUND)
					      .entity(e.getMessage())
					      .build();
					}
		}
		
		public void ApproveUser(Customer customer1) throws CustomerNotEligibleException, CustomerAlreadyPresentException {
			// TODO Auto-generated method stub
			
		}
		@POST
		@Path("/addproduct")
		public Response AddProductService(Product product1) throws ProductAlreadyExistsException {
			// TODO Auto-generated method stub
			try {
				adminService.AddProductService(product1);
				
				return Response
					      .status(Response.Status.OK)
					      .entity("record added")
					      .build();
					} catch (ProductAlreadyExistsException e) {
						return Response
					      .status(Response.Status.NOT_FOUND)
					      .entity(e.getMessage())
					      .build();
					}
		}
	}
package Service;

public class CustomerNotEligibleException extends Exception {

	public CustomerNotEligibleException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
}
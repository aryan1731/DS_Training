package Service;

public class CustomerAlreadyPresentException extends Exception {

	public CustomerAlreadyPresentException(String Message) {
		super(Message);
		// TODO Auto-generated constructor stub
	}
}

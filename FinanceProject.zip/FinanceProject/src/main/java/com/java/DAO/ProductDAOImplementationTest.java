package com.java.DAO;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import com.java.entities.Product;

class ProductDAOImplementationTest {
	ProductDAO proddao = new ProductDAOImplementation();

	@Test
	void test() {

		System.out.println("Test started..");
		Assertions.assertTrue(proddao != null);
		System.out.println("Got the DAO : " + proddao);
		 Product prod1 = new Product(2, "iphone", "smartphone", 70000, "iphone.jpg");
		 proddao.insertProduct(prod1);
		// proddao.updateProduct(prod1);
		 List<Product> prodobj = proddao.selectAllProducts();
//		proddao.deleteProduct(10);
		 System.out.println("PROD Obj : " + prodobj);
		System.out.println("Test over...");
	}

}

/*
 * Product selectProduct(int productId);
 * 
 * List<Product> selectAllProducts();
 * 
 * void insertProduct(Product product1);
 * 
 * void updateProduct(Product product1);
 * 
 * void deleteProduct(int productId);
 */

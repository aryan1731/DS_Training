package com.java.Service;

import static org.junit.Assert.*;

import org.junit.Test;

public class UserServiceImplementationTest {
	UserServiceImplementation userService = new UserServiceImplementation();
	@Test
	public void testPlaceOrder() {
		try {
			userService.PlaceOrder(9, 7, 3);
		} catch (InsufficientCreditLimitException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void testViewEMI() {
		System.out.println(userService.ViewEMI(7));
	}

	@Test
	public void testViewBalance() {
		System.out.println(userService.ViewBalance(7));
	}

}

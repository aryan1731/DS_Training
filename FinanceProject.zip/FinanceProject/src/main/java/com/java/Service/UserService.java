package com.java.Service;

import java.util.List;

import com.java.DAO.*;
import com.java.entities.Customer;
import com.java.entities.Product;

public interface UserService {
//	Product product1 = null;
	/*add product to orderlist	 */
	void RegisterUser(Customer customer1) throws CustomerAlreadyPresentException, CustomerNotEligibleException;
	//insertCustomer
	void PlaceOrder(int productId, int customerId, int emiPeriod) throws InsufficientCreditLimitException;
	
	int ViewEMI(int customerId);
	
	int ViewBalance(int customerId);
}

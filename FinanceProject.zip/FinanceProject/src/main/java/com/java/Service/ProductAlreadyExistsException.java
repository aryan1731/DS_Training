package com.java.Service;

public class ProductAlreadyExistsException extends Exception {
	public ProductAlreadyExistsException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
}

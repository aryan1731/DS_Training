package com.java.Service;

import java.util.List;

import com.java.entities.OrderDetails;

public interface OrderDetailsService {
	void placeOrder(int emiPeriod, int customerId, int productId) throws InsufficientCreditLimitException;

	OrderDetails viewAnOrder(int orderId);

	List<OrderDetails> viewAllCutomersOrderHistory();
}

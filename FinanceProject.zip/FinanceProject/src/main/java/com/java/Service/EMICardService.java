package com.java.Service;

import java.util.List;

import com.java.entities.EMICard;

public interface EMICardService {
	void grantEMICardService(int customerId, String cardType);

	void revokeEMICardService(int customerId);

	void updateEMICardService(EMICard emiCard);

	EMICard viewEMICard(int customerId);

	List<EMICard> viewAllEMICards();
}

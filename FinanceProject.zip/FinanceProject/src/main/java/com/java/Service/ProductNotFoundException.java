package com.java.Service;

public class ProductNotFoundException extends Exception {

	public ProductNotFoundException(String msg) {
		super(msg);
		// TODO Auto-generated constructor stub
	}
}
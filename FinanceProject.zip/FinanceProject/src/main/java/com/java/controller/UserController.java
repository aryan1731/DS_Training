package com.java.controller;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import com.java.Service.CustomerAlreadyPresentException;
import com.java.Service.CustomerNotEligibleException;
import com.java.Service.InsufficientCreditLimitException;
import com.java.Service.UserService;
import com.java.Service.UserServiceImplementation;
import com.java.entities.Customer;
@Path("/user/")
public class UserController {

	UserService userService = new UserServiceImplementation();
	
	
	//CustomerID | Name  | PhoneNo   | Email        | UserName | Password | Address | Age  | Salary | CardType	
		@GET @Path("/newuser/{custid}/{name}/{phoneno}/{email}/{username}/{password}/{address}/{age}/{salary}/{cardType}")
		public Response RegisterUser(@PathParam("custid") int customerId, @PathParam("name") String name,@PathParam("phoneno") long phoneNo, @PathParam("email") String email, @PathParam("username") String userName,  @PathParam("password") String password,@PathParam("address") String address, @PathParam("age") int age, @PathParam("salary") int salary, @PathParam("cardType") String cardType) throws CustomerNotEligibleException {
			// TODO Auto-generated method stub
//			customerdao.insertCustomer(customer1);
			 Customer customer1 = new Customer(customerId,name,phoneNo,email,userName,password,address,age,salary,cardType);
			try {
				userService.RegisterUser(customer1);
				return Response
					      .status(Response.Status.OK)
					      .entity("user added")
					      .build();
			} catch (CustomerAlreadyPresentException e) {
				return Response
					      .status(Response.Status.NOT_FOUND)
					      .entity(e.getMessage())
					      .build();
			}
			
		}
		//
		@GET @Path("/viewemi/{custid}")
		public int ViewEMI(@PathParam("custid") int customerId) {
			// TODO Auto-generated method stub
			return userService.ViewEMI(customerId);
		}
		@GET @Path("/viewbalance/{custid}")
		public int ViewBalance(@PathParam("custid") int customerId) {
			// TODO Auto-generated method stub
			return userService.ViewBalance(customerId);
		}
		@GET
		@Path ("/placeOrder/{custid}/{pid}/{emiPeriod}")
//		public Response placeOrder(@PathParam("pid") int productId, @PathParam("emiPeriod") int emiPeriod, @PathParam("custid") int customerId) 
		public Response placeOrder(@PathParam("custid") int customerId, @PathParam("pid") int productId, @PathParam("emiPeriod") int emiPeriod ) {
			// TODO Auto-generated method stub
			try {
				userService.PlaceOrder(productId, customerId, emiPeriod);
				return Response
					      .status(Response.Status.OK)
					      .entity("Order Placed")
					      .build();
			} catch (InsufficientCreditLimitException e) {
				return Response.status(Response.Status.NOT_ACCEPTABLE)
						.entity(e.getMessage())
						.build();

			}
		}
}

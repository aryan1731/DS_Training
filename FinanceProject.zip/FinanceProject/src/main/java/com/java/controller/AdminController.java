package com.java.controller;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.java.Service.AdminService;
import com.java.Service.AdminServiceImplementation;
import com.java.Service.CustomerAlreadyPresentException;
import com.java.Service.CustomerNotEligibleException;
import com.java.Service.CustomerNotFoundException;
import com.java.Service.ProductAlreadyExistsException;
import com.java.entities.Customer;
import com.java.entities.Product;

//@Path("/currencies") // http://localhost:8082/FinanceProject/rest/admin/greet
@Path("/admin")
public class AdminController {
	AdminService adminService = new AdminServiceImplementation();
	
	@GET				//action mappings
	@Path("/greet") //http://localhost:8080/MyRestAPI2/rest/currency/greet
	public String welcome() {
		return "<h1> Welcome to Web Based Controller </h1>";
	}
	
	@GET  @Produces(MediaType.APPLICATION_JSON)
	@Path("/alluser")//http://localhost:8080/FinanceProject/rest/admin
	public List<Customer> Viewalluser() {
			// TODO Auto-generated method stub
		System.out.println("controller : viewalluser()");
		return adminService.Viewalluser();
	}
		
		@GET
		@Path("/delete/{cid}")
		public Response RevokeUser(@PathParam("cid") int id) {
			
			adminService.RevokeUser(id);
			
			return Response
					.status(Response.Status.OK)
					.entity("User Deleted")
					.build();

		}
		
		@GET @Path("/modifyuser/{custid}/{name}/{phoneno}/{email}/{username}/{password}/{address}/{age}/{salary}/{cardType}")
		public Response ModifyUser(@PathParam("custid") int customerId, @PathParam("name") String name,@PathParam("phoneno") long phoneNo, @PathParam("email") String email, @PathParam("username") String userName,  @PathParam("password") String password,@PathParam("address") String address, @PathParam("age") int age, @PathParam("salary") int salary, @PathParam("cardType") String cardType) throws CustomerNotFoundException {
			try {
				Customer customer1 = new Customer(customerId,name,phoneNo,email,userName,password,address,age,salary,cardType);
				adminService.ModifyUser(customer1);
				return Response
					      .status(Response.Status.OK)
					      .entity("User Modified")
					      .build();
					} catch (CustomerNotFoundException e) {
						return Response
					      .status(Response.Status.NOT_FOUND)
					      .entity(e.getMessage())
					      .build();
					}
		}
		
		public void ApproveUser(Customer customer1) throws CustomerNotEligibleException, CustomerAlreadyPresentException {
			// TODO Auto-generated method stub
			
		}
		@POST
		@Path("/addproduct")
		public Response AddProductService(Product product1) throws ProductAlreadyExistsException {
			// TODO Auto-generated method stub
			try {
				adminService.AddProductService(product1);
				
				return Response
					      .status(Response.Status.OK)
					      .entity("record added")
					      .build();
					} catch (ProductAlreadyExistsException e) {
						return Response
					      .status(Response.Status.NOT_FOUND)
					      .entity(e.getMessage())
					      .build();
					}
		}
	}